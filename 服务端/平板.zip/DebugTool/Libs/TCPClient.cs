﻿using System;
using System.Configuration;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;

namespace DebugTool.Libs
{
    public class TCPClient
    {
        private static readonly object _instanceLock = new object();
        private static TCPClient _instance = null;

        private TCPClient() { }

        public static TCPClient Instance
        {
            get
            {
                if (null == _instance)
                {
                    lock (_instanceLock)
                    {
                        if (null == _instance)
                        {
                            _instance = new TCPClient();
                        }
                    }
                }
                return _instance;
            }
        }

        Socket clientSocket;
        public bool Init()
        {
            try
            {
                string ip = "";
                string port = "";
                clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);//InterNetwork:IPv4  Stream:字节流  Tcp:Tcp协议
                clientSocket.Connect(new IPEndPoint(IPAddress.Parse(ip), int.Parse(port)));
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void Receive()
        {
            byte[] data = new byte[1024];
            int count = clientSocket.Receive(data);//获取消息长度
            string msg = Encoding.UTF8.GetString(data, 0, count);//将byte[]转换成string
            Thread.Sleep(5000);

            string result = "ok";
            clientSocket.Send(Encoding.UTF8.GetBytes(result));//将信息string转换成byte[]发送至服务器

            //clientSocket.Close();//关闭
        }

        public string Send(string msg)
        {
            try
            {
                //向服务端发送一条消息
                byte[] data = Encoding.UTF8.GetBytes(msg);//把string转换成byte[]
                clientSocket.Send(data);//向服务端发送一条信息

                //接受服务端的一条信息
                byte[] dataBuffer = new byte[1024];
                int count = clientSocket.Receive(dataBuffer);//获取字节真实长度
                string msgReceive = Encoding.UTF8.GetString(dataBuffer, 0, count);//将收到的byte[]转换成string
                if (string.IsNullOrEmpty(msgReceive)) clientSocket = null;
                //clientSocket.Close();
                return msgReceive;
            }
            catch(Exception ex)
            {
                return "error: 通讯发生故障.";
            }
        }
    }
}
