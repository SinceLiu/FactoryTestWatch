﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace DebugTool.Libs
{
    public class Phone
    {
        //服务器IP（主控端使用字段）
        public string ip { get; set; }
        //产品号（主控端使用字段）
        public int num { get; set; }
        //socket为null（主控端使用字段）
        public Socket socket { get; set; }
        public string sn { get; set; }
        //校准、综测、耦合标记位x,y,z
        public string flag { get; set; }
        //光线传感器
        public string light { get; set; }
        //加速度传感器
        public string accelerometer { get; set; }
        //距离传感器
        public string proximity { get; set; }
        //地磁传感器
        public string magnetometer { get; set; }
        //陀螺仪传感器
        public string gyroscope { get; set; }
        //使用前摄或后摄,后摄（0） | 前摄（1），格式：<后摄（0） | 前摄（1）>@<测试项名称>
        public string camera { get; set; }
        //辅助摄像
        public string AuxiliaryCamera { get; set; }
        public string wifi { get; set; }
        public string gps { get; set; }
        public string bluetooth { get; set; }
        public string sd { get; set; }
        public string otg { get; set; }
        public string sim { get; set; }
        //录音播音（打开环回）
        public string record { get; set; }
        //振动器
        public string vibrator { get; set; }
        //拨号
        public string dial { get; set; }
        //版本号
        public string version { get; set; }
        //温度、电压、电量x,y,z
        public string battery { get; set; }
        //充电电流
        public string electricity { get; set; }
        //总容量与已用空间容量
        public string disk { get; set; }
        //按键
        public string key { get; set; }
        //触摸屏
        public string touch { get; set; }
        //提示灯:"red\blue\green\close"
        public string tip { get; set; }
        //屏幕显示："black blue green red white close"
        public string screen { get; set; }

        #region 手表测试项
        //cpu
        public string cpu { get; set; }

        //板卡
        public string board { get; set; }

        //IMEI
        public string IMEI { get; set; }

        //充电电流和状态一起滚回来，逗号隔开
        public string charge { get; set; }
        //adc状态
        public string adc { get; set; }

        #endregion

        //关机
        public string shutdown { get; set; }
        //界面显示行信息
        public string showMessage { get; set; }
        //数据返回延时时间
        public int timeout { get; set; }
        //当前工站（主控端使用字段）
        public string curStation { get; set; }

        public int ScreenOperation { get; set; }
        //工站列表
        public List<Station> stationList { get; set; }

        private int SlowTime = 0;

        public void AddSlowTime()
        {
            SlowTime++;
        }

        public int GetSlowtime()
        {
            return SlowTime;
        }
    }

    public class Station
    {
        public string Name { get; set; }
        public List<TestItem> TestItemList { get; set; }
    }

    public class TestItem
    {
        public string Name { get; set; }
        public string EName { get; set; }
        public string Property { get; set; }
        public string Value { get; set; }
        public object UpLimit { get; set; }
        public bool IsContainUpLimit { get; set; }
        public object LowLimit { get; set; }
        public bool IsContainLowLimit { get; set; }
        public bool IsEnabled { get; set; }
        public bool? TestResult { get; set; }
    }

    public class CameraParam
    {
        //分辨率：相机支持的分辨率，宽>高（宽:高）
        public string resolutionRatio { get; set; }
        //是否开启对焦
        public bool isFocus { get; set; }
        //闪光灯模式：关闭（0） | 开启（1） | 自动（3）
        public string flashMode { get; set; }
        //照片压缩率：正整数（默认：1，不压缩）
        public string compressionRatio { get; set; }
    }

    public class Touch
    {
        public string down { get; set; }
        public string[] move { get; set; }
        public string up { get; set; }
    }

    public class Camera
    {
        //IP:192.168.1.200 PORT:6000
        //格式："SN,TestItemName,FileName,TestResult,Data"
        public string SN { get; set; }
        //LCD除尘（黑屏亮灯）、LCD黑屏（黑屏灭灯）、LCD白屏（白屏灭灯）、后摄白场、后摄黑场、前摄白场、前摄黑场、前摄近焦、后摄近焦、后摄远焦
        public string TestItemName { get; set; }
        public string FileName { get; set; }
        public bool TestResult { get; set; }
        public string Data { get; set; }
    }
}
