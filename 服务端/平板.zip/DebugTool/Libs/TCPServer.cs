﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Linq;

namespace DebugTool.Libs
{
    public class TCPServer
    {
        private static readonly object _instanceLock = new object();
        private static TCPServer _instance = null;
        private TCPServer() { }

        Dictionary<Phone, string> PhonesAndLastMsg = new Dictionary<Phone, string>();

        public static TCPServer Instance
        {
            get
            {
                if (null == _instance)
                {
                    lock (_instanceLock)
                    {
                        if (null == _instance)
                        {
                            _instance = new TCPServer();
                        }
                    }
                }
                return _instance;
            }
        }

        Socket serverSocket;
        public void Init()
        {
            try
            {
                string hostName = Dns.GetHostName();   //获取本机名
                IPHostEntry localhost = Dns.GetHostByName(hostName);    //方法已过期，可以获取IPv4的地址
                //IPHostEntry localhost = Dns.GetHostEntry(hostName);   //获取IPv6地址
                serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);//InterNetwork:IPv4  Stream:字节流  Tcp:Tcp协议
                IPAddress ipAddress = localhost.AddressList[0];//新建一个IP地址
                int port = 12345;
                IPEndPoint ipEndPoint = new IPEndPoint(ipAddress, port);//新建一个绑定IP的端口号
                serverSocket.Bind(ipEndPoint);//绑定IP和端口号
                serverSocket.Listen(0);//开始监听端口号      (5:处理连接个数 0:不限制)  
                Thread thread = new Thread(AcceptInfo);
                thread.IsBackground = true;
                thread.Start(serverSocket);
                //serverSocket.Close();
                ShowMessage(string.Format("服务器{0}已开启.", ipAddress.ToString()));
            }
            catch(Exception ex)
            {
                ShowMessage?.Invoke("【Error】 服务器开启错误，详细：" + ex.Message);
                MessageBox.Show(ex.Message, "服务器开启错误");
            }
        }

        public List<Phone> Phones = new List<Phone>();
        public event Action<string> Update;
        public event Action<string> ShowMessage;
        public event Action<string> Disconn;
        private void AcceptInfo(object o)
        {
            Socket socket = o as Socket;
            while(true)
            {
                try
                {
                    Phone inst = new Phone();
                    inst.socket = socket.Accept();
                    inst.ip = inst.socket.RemoteEndPoint.ToString();                   
                    Phones.Add(inst);
                    Update?.Invoke(inst.ip);

                    //Thread threadReceive = new Thread(Receive);
                    //threadReceive.IsBackground = true;
                    //threadReceive.Start(inst);

                    //Thread threadConnectCheck = new Thread(ConnectCheck);
                    //threadConnectCheck.IsBackground = true;
                    //threadConnectCheck.Start(inst);
                }
                catch(Exception ex)
                {
                    ShowMessage?.Invoke("【Error】 连接错误，详细：" + ex.Message);
                    MessageBox.Show(ex.Message, "连接错误");
                    socket.Close();
                    break;
                }
            }
        }

        public void SendWithoutReceive(Phone p, int timeout = 0)
        {
            
            timeout = 4;
            Socket socket = p.socket;
            List<Station> stationList = p.stationList;
            try
            {
                FlushReceive(socket);
                p.socket = null;

                p.stationList = null;
                string msg = JsonConvert.SerializeObject(p);
                p.socket = socket;
                //向客户端发送一条消息
                byte[] data = { };
                data = Encoding.UTF8.GetBytes(msg);//把string转换成byte[]

                socket.ReceiveTimeout = timeout * 1000;
                socket.Send(data);//向客户端发送一条信息
                ShowMessage?.Invoke("*******************");
                ShowMessage?.Invoke(p.sn + "发送：" + msg);
                p.stationList = stationList;

            }
            catch (Exception ex)
            {
                p.socket = socket;
                p.stationList = stationList;
                return;
            }
        }

        private void FlushReceive(Socket s)
        {
            s.ReceiveTimeout = 20;
            while (true)
            {
                try
                {
                    byte[] dataBuffer = new byte[1024 * 8];
                    int count = s.Receive(dataBuffer);
                    if (count == 0)
                    {
                        return;
                    }
                    string msgReceive = Encoding.UTF8.GetString(dataBuffer, 0, count);
                    ShowMessage?.Invoke("缓存区清除数据:" + msgReceive);
                }
                catch
                {

                    return;
                }

            }
        }

        /// <summary>
        /// 同步接收拆分函数
        /// </summary>
        /// <param name="p"></param>
        public string AsSynReceive(Phone p)
        {
            if (p.socket == null)
            {
                ShowMessage?.Invoke(p.sn + "Socet为Null不接收");
                return "";
            }
            string msgReceive = "";
            try
            {
                Socket socket = p.socket;

                byte[] dataBuffer = new byte[1024 * 12];
                int count = socket.Receive(dataBuffer);

                msgReceive = Encoding.UTF8.GetString(dataBuffer, 0, count);

                ShowMessage?.Invoke("接收：" + msgReceive.Replace('\0','\r'));

                //seq不需要处理
                if (msgReceive.Contains("seq") || msgReceive.Contains("alive"))
                {
                    return msgReceive;
                }

                Type t = typeof(Phone);
                Phone retphones = null;

                foreach (var phone in Phones)
                {
                    if (phone.ip == p.ip)
                    {
                        if (msgReceive.Contains("MOVE"))
                        {
                            phone.touch = msgReceive;
                            return msgReceive;
                        }
                        if (p.key == "get")
                        {
                            phone.key = msgReceive;
                            return msgReceive;
                        }
                        if (p.bluetooth == "get")
                        {
                            string startflag = "\"bluetooth\":\"";
                            int startpos = msgReceive.IndexOf(startflag);
                            int stoppos = msgReceive.IndexOf(",\"ip\"");
                            p.bluetooth = msgReceive.Substring(startpos + startflag.Length, stoppos - startpos - startflag.Length - 1);
                            return msgReceive;
                        }
                        else
                        {
                            //retphones = JsonConvert.DeserializeObject<Phone>(msgReceive);
                        }

                        //foreach (var item in t.GetProperties())
                        //{
                        //    if (item.GetValue(p) != null && item.GetValue(p).ToString() == "get")
                        //    {
                        //        item.SetValue(phone, item.GetValue(retphones));
                        //        ShowMessage?.Invoke(p.sn + " " + item.ToString() + "获取到值：" + item.GetValue(retphones).ToString());
                        //    }
                        //}

                    }
                }

                //ReceiveSyn(p, dataBuffer);
            }
            catch (Exception ex)
            {
                ShowMessage?.Invoke(p.sn + "没有接收到返回");
                ShowMessage?.Invoke("*******************");
                ShowMessage?.Invoke(p.sn + "已经断开连接，不再测试");
                return "error";
            }
            return msgReceive;

        }

        private void Receive(object o)
        {
            Phone inst = o as Phone;
            while (true)
            {
                if (inst.socket == null) inst = o as Phone;
                try
                {
                    byte[] dataBuffer = new byte[1024 * 10];
                    int count = inst.socket.Receive(dataBuffer);//获取字节真实长度
                    if (dataBuffer[0] == 0)  // 表示接收到的是数据； 
                    {
                        string msgReceive = Encoding.UTF8.GetString(dataBuffer, 1, count - 1);//将收到的byte[]转换成string
                        ShowMessage?.Invoke("接收到信息：" + msgReceive);

                        if (msgReceive.Contains("MOVE"))
                        {
                            inst.touch = msgReceive;
                            MessageBox.Show(msgReceive.Split(',').Length.ToString());
                        }
                        else if (inst.bluetooth == "get")
                        {
                            ShowMessage?.Invoke("接收到信息：" + msgReceive);
                            return;
                        }
                        else
                        {
                            inst = JsonConvert.DeserializeObject<Phone>(msgReceive);
                        }
                        for (int i = 0; i < Phones.Count; i++)
                        {
                            if (Phones[i].ip == inst.ip)
                            {
                                inst.socket = Phones[i].socket;
                                Phones[i] = inst;
                            }
                        }
                    }
                    else
                    {
                        string msgReceive = Encoding.UTF8.GetString(dataBuffer, 0, count);
                        ShowMessage?.Invoke("接收到信息：" + msgReceive);
                        byte[] data = Encoding.UTF8.GetBytes("ok");//把string转换成byte[]
                        inst.socket.Send(data);
                    }
                    //}
                }
                catch (SocketException se)
                {
                    inst.socket.Close();
                    ShowMessage?.Invoke("【Error】 消息接收错误，详细：" + se.Message);
                    Disconn?.Invoke(inst.ip);
                    break;
                }
                catch (Exception ex)
                {
                    inst.socket.Close();
                    if (ex.Message.Contains("要求非负数。"))
                    {
                        Disconn?.Invoke(inst.ip);
                        break;
                    }
                    //else if(ex.Message.Contains("After parsing a value an unexpected character was encountere"))
                    //{
                    //    //过滤异常
                    //}
                    else
                    {
                        ShowMessage?.Invoke("【Error】 消息接收错误，详细：" + ex.Message);
                        break;
                    }
                    //Array.Clear(dataBuffer, 0, dataBuffer.Length);
                    //MessageBox.Show(ex.Message, "消息接收错误");
                    //break;
                }
            }
        }

        private void ConnectCheck(object o)
        {
            Phone inst = o as Phone;
            //while (true)
            //{
            try
            {
                if (inst.socket.Poll(-1, SelectMode.SelectRead))
                {
                    byte[] temp = new byte[1024];
                    int nRead = inst.socket.Receive(temp);
                    if (nRead == 0)
                    {
                        Disconn?.Invoke(inst.ip);
                    }
                }
            }
            catch (Exception ex)
            {
                inst.socket.Close();
                ShowMessage?.Invoke("【Error】 断开连接错误，详细：" + ex.Message);
                MessageBox.Show(ex.Message, "断开连接错误");
                //break;
            }
            //}
        }

        public void SendUnCompleteStr(Phone p)
        {
            Socket socket = p.socket;
            try
            {
                p.socket = null;
                string msg = JsonConvert.SerializeObject(p).Substring(10);
                p.socket = socket;
                ShowMessage?.Invoke("发送信息：" + msg);
                //向客户端发送一条消息
                byte[] data = Encoding.UTF8.GetBytes(msg);//把string转换成byte[]
                if (PhonesAndLastMsg.ContainsKey(p))
                {
                    PhonesAndLastMsg[p] = msg;
                }
                else
                {
                    PhonesAndLastMsg.Add(p, msg);
                }
                socket.Send(data);//向客户端发送一条信息
            }
            catch (Exception ex)
            {
                socket.Close();
                ShowMessage?.Invoke("【Error】 消息发送错误，详细：" + ex.Message);
                MessageBox.Show(ex.Message, "消息发送错误");
            }
        }

        public void Send(Phone p)
        {
            Socket socket = p.socket;
            try
            {
                p.socket = null;
                string msg = JsonConvert.SerializeObject(p);
                p.socket = socket;
                ShowMessage?.Invoke("发送信息：" + msg);
                //向客户端发送一条消息
                byte[] data = Encoding.UTF8.GetBytes(msg);//把string转换成byte[]
                if(PhonesAndLastMsg.ContainsKey(p))
                {
                    PhonesAndLastMsg[p] = msg;
                }
                else
                {
                    PhonesAndLastMsg.Add(p, msg);
                }
                socket.Send(data);//向客户端发送一条信息
            }
            catch (Exception ex)
            {
                socket.Close();
                ShowMessage?.Invoke("【Error】 消息发送错误，详细：" + ex.Message);
                MessageBox.Show(ex.Message, "消息发送错误");
            }
        }

        public void SendLast(Phone p)
        {
            Socket socket = p.socket;
            try
            {
                p.socket = null;
                string msg = PhonesAndLastMsg[p];
                p.socket = socket;
                ShowMessage?.Invoke("发送信息：" + msg);
                //向客户端发送一条消息
                byte[] data = Encoding.UTF8.GetBytes(msg);//把string转换成byte[]              
                socket.Send(data);//向客户端发送一条信息
            }
            catch (Exception ex)
            {
                socket.Close();
                ShowMessage?.Invoke("【Error】 消息发送错误，详细：" + ex.Message);
                MessageBox.Show(ex.Message, "消息发送错误");
            }
        }
    }
}
