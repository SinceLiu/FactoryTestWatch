﻿namespace DebugTool
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tbLog = new System.Windows.Forms.TextBox();
            this.btnInit = new System.Windows.Forms.Button();
            this.btnSN = new System.Windows.Forms.Button();
            this.cbDTU = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFlag = new System.Windows.Forms.Button();
            this.btnLight = new System.Windows.Forms.Button();
            this.btnAcc = new System.Windows.Forms.Button();
            this.btnPro = new System.Windows.Forms.Button();
            this.btnMag = new System.Windows.Forms.Button();
            this.btnGyr = new System.Windows.Forms.Button();
            this.btnCamera1 = new System.Windows.Forms.Button();
            this.btnCamera0 = new System.Windows.Forms.Button();
            this.btnWifi = new System.Windows.Forms.Button();
            this.btnGps = new System.Windows.Forms.Button();
            this.btnBluetooth = new System.Windows.Forms.Button();
            this.btnSD = new System.Windows.Forms.Button();
            this.btnOtg = new System.Windows.Forms.Button();
            this.btnSim = new System.Windows.Forms.Button();
            this.btnRecord = new System.Windows.Forms.Button();
            this.btnVib = new System.Windows.Forms.Button();
            this.btnDial = new System.Windows.Forms.Button();
            this.btnVer = new System.Windows.Forms.Button();
            this.btnBattery = new System.Windows.Forms.Button();
            this.btnDisk = new System.Windows.Forms.Button();
            this.btnKey = new System.Windows.Forms.Button();
            this.btnTouch = new System.Windows.Forms.Button();
            this.btnTip = new System.Windows.Forms.Button();
            this.btnRedScreen = new System.Windows.Forms.Button();
            this.btnGreenScreen = new System.Windows.Forms.Button();
            this.btnBlue = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbLog
            // 
            this.tbLog.AllowDrop = true;
            this.tbLog.Location = new System.Drawing.Point(9, 284);
            this.tbLog.Margin = new System.Windows.Forms.Padding(2);
            this.tbLog.Multiline = true;
            this.tbLog.Name = "tbLog";
            this.tbLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbLog.Size = new System.Drawing.Size(731, 237);
            this.tbLog.TabIndex = 0;
            // 
            // btnInit
            // 
            this.btnInit.Location = new System.Drawing.Point(9, 10);
            this.btnInit.Margin = new System.Windows.Forms.Padding(2);
            this.btnInit.Name = "btnInit";
            this.btnInit.Size = new System.Drawing.Size(76, 26);
            this.btnInit.TabIndex = 1;
            this.btnInit.Text = "开启服务器";
            this.btnInit.UseVisualStyleBackColor = true;
            this.btnInit.Click += new System.EventHandler(this.btnInit_Click);
            // 
            // btnSN
            // 
            this.btnSN.Location = new System.Drawing.Point(106, 10);
            this.btnSN.Margin = new System.Windows.Forms.Padding(2);
            this.btnSN.Name = "btnSN";
            this.btnSN.Size = new System.Drawing.Size(76, 26);
            this.btnSN.TabIndex = 2;
            this.btnSN.Text = "SN码";
            this.btnSN.UseVisualStyleBackColor = true;
            this.btnSN.Click += new System.EventHandler(this.btnSN_Click);
            // 
            // cbDTU
            // 
            this.cbDTU.FormattingEnabled = true;
            this.cbDTU.Location = new System.Drawing.Point(43, 255);
            this.cbDTU.Margin = new System.Windows.Forms.Padding(2);
            this.cbDTU.Name = "cbDTU";
            this.cbDTU.Size = new System.Drawing.Size(140, 20);
            this.cbDTU.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 258);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "DTU:";
            // 
            // btnFlag
            // 
            this.btnFlag.Location = new System.Drawing.Point(208, 10);
            this.btnFlag.Margin = new System.Windows.Forms.Padding(2);
            this.btnFlag.Name = "btnFlag";
            this.btnFlag.Size = new System.Drawing.Size(206, 26);
            this.btnFlag.TabIndex = 5;
            this.btnFlag.Text = "校准/综测/耦合标记位（未调通）";
            this.btnFlag.UseVisualStyleBackColor = true;
            this.btnFlag.Click += new System.EventHandler(this.btnFlag_Click);
            // 
            // btnLight
            // 
            this.btnLight.Location = new System.Drawing.Point(442, 10);
            this.btnLight.Margin = new System.Windows.Forms.Padding(2);
            this.btnLight.Name = "btnLight";
            this.btnLight.Size = new System.Drawing.Size(76, 26);
            this.btnLight.TabIndex = 6;
            this.btnLight.Text = "光线传感器";
            this.btnLight.UseVisualStyleBackColor = true;
            this.btnLight.Click += new System.EventHandler(this.btnLight_Click);
            // 
            // btnAcc
            // 
            this.btnAcc.Location = new System.Drawing.Point(542, 10);
            this.btnAcc.Margin = new System.Windows.Forms.Padding(2);
            this.btnAcc.Name = "btnAcc";
            this.btnAcc.Size = new System.Drawing.Size(87, 26);
            this.btnAcc.TabIndex = 7;
            this.btnAcc.Text = "加速度传感器";
            this.btnAcc.UseVisualStyleBackColor = true;
            this.btnAcc.Click += new System.EventHandler(this.btnAcc_Click);
            // 
            // btnPro
            // 
            this.btnPro.Location = new System.Drawing.Point(652, 10);
            this.btnPro.Margin = new System.Windows.Forms.Padding(2);
            this.btnPro.Name = "btnPro";
            this.btnPro.Size = new System.Drawing.Size(87, 26);
            this.btnPro.TabIndex = 8;
            this.btnPro.Text = "距离传感器";
            this.btnPro.UseVisualStyleBackColor = true;
            this.btnPro.Click += new System.EventHandler(this.btnPro_Click);
            // 
            // btnMag
            // 
            this.btnMag.Location = new System.Drawing.Point(106, 60);
            this.btnMag.Margin = new System.Windows.Forms.Padding(2);
            this.btnMag.Name = "btnMag";
            this.btnMag.Size = new System.Drawing.Size(87, 26);
            this.btnMag.TabIndex = 9;
            this.btnMag.Text = "地磁传感器";
            this.btnMag.UseVisualStyleBackColor = true;
            this.btnMag.Click += new System.EventHandler(this.btnMag_Click);
            // 
            // btnGyr
            // 
            this.btnGyr.Location = new System.Drawing.Point(208, 60);
            this.btnGyr.Margin = new System.Windows.Forms.Padding(2);
            this.btnGyr.Name = "btnGyr";
            this.btnGyr.Size = new System.Drawing.Size(87, 26);
            this.btnGyr.TabIndex = 10;
            this.btnGyr.Text = "陀螺仪传感器";
            this.btnGyr.UseVisualStyleBackColor = true;
            this.btnGyr.Click += new System.EventHandler(this.btnGyr_Click);
            // 
            // btnCamera1
            // 
            this.btnCamera1.Location = new System.Drawing.Point(326, 60);
            this.btnCamera1.Margin = new System.Windows.Forms.Padding(2);
            this.btnCamera1.Name = "btnCamera1";
            this.btnCamera1.Size = new System.Drawing.Size(87, 26);
            this.btnCamera1.TabIndex = 11;
            this.btnCamera1.Text = "前摄像头";
            this.btnCamera1.UseVisualStyleBackColor = true;
            this.btnCamera1.Click += new System.EventHandler(this.btnCamera1_Click);
            // 
            // btnCamera0
            // 
            this.btnCamera0.Location = new System.Drawing.Point(442, 60);
            this.btnCamera0.Margin = new System.Windows.Forms.Padding(2);
            this.btnCamera0.Name = "btnCamera0";
            this.btnCamera0.Size = new System.Drawing.Size(87, 26);
            this.btnCamera0.TabIndex = 12;
            this.btnCamera0.Text = "后摄像头";
            this.btnCamera0.UseVisualStyleBackColor = true;
            this.btnCamera0.Click += new System.EventHandler(this.btnCamera0_Click);
            // 
            // btnWifi
            // 
            this.btnWifi.Location = new System.Drawing.Point(542, 60);
            this.btnWifi.Margin = new System.Windows.Forms.Padding(2);
            this.btnWifi.Name = "btnWifi";
            this.btnWifi.Size = new System.Drawing.Size(87, 26);
            this.btnWifi.TabIndex = 13;
            this.btnWifi.Text = "Wifi";
            this.btnWifi.UseVisualStyleBackColor = true;
            this.btnWifi.Click += new System.EventHandler(this.btnWifi_Click);
            // 
            // btnGps
            // 
            this.btnGps.Location = new System.Drawing.Point(652, 60);
            this.btnGps.Margin = new System.Windows.Forms.Padding(2);
            this.btnGps.Name = "btnGps";
            this.btnGps.Size = new System.Drawing.Size(87, 26);
            this.btnGps.TabIndex = 14;
            this.btnGps.Text = "GPS";
            this.btnGps.UseVisualStyleBackColor = true;
            this.btnGps.Click += new System.EventHandler(this.btnGps_Click);
            // 
            // btnBluetooth
            // 
            this.btnBluetooth.Location = new System.Drawing.Point(106, 112);
            this.btnBluetooth.Margin = new System.Windows.Forms.Padding(2);
            this.btnBluetooth.Name = "btnBluetooth";
            this.btnBluetooth.Size = new System.Drawing.Size(87, 26);
            this.btnBluetooth.TabIndex = 15;
            this.btnBluetooth.Text = "蓝牙";
            this.btnBluetooth.UseVisualStyleBackColor = true;
            this.btnBluetooth.Click += new System.EventHandler(this.btnBluetooth_Click);
            // 
            // btnSD
            // 
            this.btnSD.Location = new System.Drawing.Point(208, 112);
            this.btnSD.Margin = new System.Windows.Forms.Padding(2);
            this.btnSD.Name = "btnSD";
            this.btnSD.Size = new System.Drawing.Size(87, 26);
            this.btnSD.TabIndex = 16;
            this.btnSD.Text = "SD卡";
            this.btnSD.UseVisualStyleBackColor = true;
            this.btnSD.Click += new System.EventHandler(this.btnSD_Click);
            // 
            // btnOtg
            // 
            this.btnOtg.Location = new System.Drawing.Point(326, 112);
            this.btnOtg.Margin = new System.Windows.Forms.Padding(2);
            this.btnOtg.Name = "btnOtg";
            this.btnOtg.Size = new System.Drawing.Size(87, 26);
            this.btnOtg.TabIndex = 17;
            this.btnOtg.Text = "OTG";
            this.btnOtg.UseVisualStyleBackColor = true;
            this.btnOtg.Click += new System.EventHandler(this.btnOtg_Click);
            // 
            // btnSim
            // 
            this.btnSim.Location = new System.Drawing.Point(442, 112);
            this.btnSim.Margin = new System.Windows.Forms.Padding(2);
            this.btnSim.Name = "btnSim";
            this.btnSim.Size = new System.Drawing.Size(87, 26);
            this.btnSim.TabIndex = 18;
            this.btnSim.Text = "SIM卡";
            this.btnSim.UseVisualStyleBackColor = true;
            this.btnSim.Click += new System.EventHandler(this.btnSim_Click);
            // 
            // btnRecord
            // 
            this.btnRecord.Location = new System.Drawing.Point(542, 112);
            this.btnRecord.Margin = new System.Windows.Forms.Padding(2);
            this.btnRecord.Name = "btnRecord";
            this.btnRecord.Size = new System.Drawing.Size(87, 26);
            this.btnRecord.TabIndex = 19;
            this.btnRecord.Text = "录音播音";
            this.btnRecord.UseVisualStyleBackColor = true;
            this.btnRecord.Click += new System.EventHandler(this.btnRecord_Click);
            // 
            // btnVib
            // 
            this.btnVib.Location = new System.Drawing.Point(652, 112);
            this.btnVib.Margin = new System.Windows.Forms.Padding(2);
            this.btnVib.Name = "btnVib";
            this.btnVib.Size = new System.Drawing.Size(87, 26);
            this.btnVib.TabIndex = 20;
            this.btnVib.Text = "震动器";
            this.btnVib.UseVisualStyleBackColor = true;
            this.btnVib.Click += new System.EventHandler(this.btnVib_Click);
            // 
            // btnDial
            // 
            this.btnDial.Location = new System.Drawing.Point(106, 167);
            this.btnDial.Margin = new System.Windows.Forms.Padding(2);
            this.btnDial.Name = "btnDial";
            this.btnDial.Size = new System.Drawing.Size(87, 26);
            this.btnDial.TabIndex = 21;
            this.btnDial.Text = "拨号";
            this.btnDial.UseVisualStyleBackColor = true;
            this.btnDial.Click += new System.EventHandler(this.btnDial_Click);
            // 
            // btnVer
            // 
            this.btnVer.Location = new System.Drawing.Point(208, 167);
            this.btnVer.Margin = new System.Windows.Forms.Padding(2);
            this.btnVer.Name = "btnVer";
            this.btnVer.Size = new System.Drawing.Size(87, 26);
            this.btnVer.TabIndex = 22;
            this.btnVer.Text = "版本号";
            this.btnVer.UseVisualStyleBackColor = true;
            this.btnVer.Click += new System.EventHandler(this.btnVer_Click);
            // 
            // btnBattery
            // 
            this.btnBattery.Location = new System.Drawing.Point(326, 167);
            this.btnBattery.Margin = new System.Windows.Forms.Padding(2);
            this.btnBattery.Name = "btnBattery";
            this.btnBattery.Size = new System.Drawing.Size(87, 26);
            this.btnBattery.TabIndex = 23;
            this.btnBattery.Text = "电池";
            this.btnBattery.UseVisualStyleBackColor = true;
            this.btnBattery.Click += new System.EventHandler(this.btnBattery_Click);
            // 
            // btnDisk
            // 
            this.btnDisk.Location = new System.Drawing.Point(442, 167);
            this.btnDisk.Margin = new System.Windows.Forms.Padding(2);
            this.btnDisk.Name = "btnDisk";
            this.btnDisk.Size = new System.Drawing.Size(87, 26);
            this.btnDisk.TabIndex = 24;
            this.btnDisk.Text = "磁盘";
            this.btnDisk.UseVisualStyleBackColor = true;
            this.btnDisk.Click += new System.EventHandler(this.btnDisk_Click);
            // 
            // btnKey
            // 
            this.btnKey.Location = new System.Drawing.Point(542, 167);
            this.btnKey.Margin = new System.Windows.Forms.Padding(2);
            this.btnKey.Name = "btnKey";
            this.btnKey.Size = new System.Drawing.Size(87, 26);
            this.btnKey.TabIndex = 25;
            this.btnKey.Text = "按键";
            this.btnKey.UseVisualStyleBackColor = true;
            this.btnKey.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnTouch
            // 
            this.btnTouch.Location = new System.Drawing.Point(442, 216);
            this.btnTouch.Margin = new System.Windows.Forms.Padding(2);
            this.btnTouch.Name = "btnTouch";
            this.btnTouch.Size = new System.Drawing.Size(87, 26);
            this.btnTouch.TabIndex = 26;
            this.btnTouch.Text = "触摸屏";
            this.btnTouch.UseVisualStyleBackColor = true;
            this.btnTouch.Click += new System.EventHandler(this.btnTouch_Click);
            // 
            // btnTip
            // 
            this.btnTip.Location = new System.Drawing.Point(106, 216);
            this.btnTip.Margin = new System.Windows.Forms.Padding(2);
            this.btnTip.Name = "btnTip";
            this.btnTip.Size = new System.Drawing.Size(87, 26);
            this.btnTip.TabIndex = 27;
            this.btnTip.Text = "通知灯(红)";
            this.btnTip.UseVisualStyleBackColor = true;
            this.btnTip.Click += new System.EventHandler(this.btnTip_Click);
            // 
            // btnRedScreen
            // 
            this.btnRedScreen.Location = new System.Drawing.Point(208, 216);
            this.btnRedScreen.Margin = new System.Windows.Forms.Padding(2);
            this.btnRedScreen.Name = "btnRedScreen";
            this.btnRedScreen.Size = new System.Drawing.Size(87, 26);
            this.btnRedScreen.TabIndex = 28;
            this.btnRedScreen.Text = "屏显(红)";
            this.btnRedScreen.UseVisualStyleBackColor = true;
            this.btnRedScreen.Click += new System.EventHandler(this.btnRedScreen_Click);
            // 
            // btnGreenScreen
            // 
            this.btnGreenScreen.Location = new System.Drawing.Point(326, 216);
            this.btnGreenScreen.Margin = new System.Windows.Forms.Padding(2);
            this.btnGreenScreen.Name = "btnGreenScreen";
            this.btnGreenScreen.Size = new System.Drawing.Size(87, 26);
            this.btnGreenScreen.TabIndex = 29;
            this.btnGreenScreen.Text = "屏显(绿)";
            this.btnGreenScreen.UseVisualStyleBackColor = true;
            this.btnGreenScreen.Click += new System.EventHandler(this.btnGreenScreen_Click);
            // 
            // btnBlue
            // 
            this.btnBlue.Location = new System.Drawing.Point(542, 216);
            this.btnBlue.Margin = new System.Windows.Forms.Padding(2);
            this.btnBlue.Name = "btnBlue";
            this.btnBlue.Size = new System.Drawing.Size(87, 26);
            this.btnBlue.TabIndex = 30;
            this.btnBlue.Text = "屏显(蓝)";
            this.btnBlue.UseVisualStyleBackColor = true;
            this.btnBlue.Click += new System.EventHandler(this.btnBlue_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(838, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 23);
            this.button1.TabIndex = 31;
            this.button1.Text = "发送不完整的字符串";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(327, 258);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 26);
            this.button2.TabIndex = 32;
            this.button2.Text = "屏显(绿)";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(208, 258);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 26);
            this.button3.TabIndex = 33;
            this.button3.Text = "屏显(红)";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(442, 258);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 26);
            this.button4.TabIndex = 34;
            this.button4.Text = "触摸屏";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(838, 167);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(87, 26);
            this.button5.TabIndex = 35;
            this.button5.Text = "反复切屏";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(838, 216);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(87, 26);
            this.button6.TabIndex = 36;
            this.button6.Text = "后摄反复拍照";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(838, 258);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 26);
            this.button7.TabIndex = 37;
            this.button7.Text = "前摄反复拍照";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(970, 167);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(87, 26);
            this.button8.TabIndex = 38;
            this.button8.Text = "停止";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(652, 167);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(87, 26);
            this.button9.TabIndex = 39;
            this.button9.Text = "辅助摄像头";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(838, 65);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(293, 21);
            this.textBox1.TabIndex = 40;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(1153, 60);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(113, 26);
            this.button10.TabIndex = 41;
            this.button10.Text = "检测文件F/P次数";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 529);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnBlue);
            this.Controls.Add(this.btnGreenScreen);
            this.Controls.Add(this.btnRedScreen);
            this.Controls.Add(this.btnTip);
            this.Controls.Add(this.btnTouch);
            this.Controls.Add(this.btnKey);
            this.Controls.Add(this.btnDisk);
            this.Controls.Add(this.btnBattery);
            this.Controls.Add(this.btnVer);
            this.Controls.Add(this.btnDial);
            this.Controls.Add(this.btnVib);
            this.Controls.Add(this.btnRecord);
            this.Controls.Add(this.btnSim);
            this.Controls.Add(this.btnOtg);
            this.Controls.Add(this.btnSD);
            this.Controls.Add(this.btnBluetooth);
            this.Controls.Add(this.btnGps);
            this.Controls.Add(this.btnWifi);
            this.Controls.Add(this.btnCamera0);
            this.Controls.Add(this.btnCamera1);
            this.Controls.Add(this.btnGyr);
            this.Controls.Add(this.btnMag);
            this.Controls.Add(this.btnPro);
            this.Controls.Add(this.btnAcc);
            this.Controls.Add(this.btnLight);
            this.Controls.Add(this.btnFlag);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbDTU);
            this.Controls.Add(this.btnSN);
            this.Controls.Add(this.btnInit);
            this.Controls.Add(this.tbLog);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbLog;
        private System.Windows.Forms.Button btnInit;
        private System.Windows.Forms.Button btnSN;
        private System.Windows.Forms.ComboBox cbDTU;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFlag;
        private System.Windows.Forms.Button btnLight;
        private System.Windows.Forms.Button btnAcc;
        private System.Windows.Forms.Button btnPro;
        private System.Windows.Forms.Button btnMag;
        private System.Windows.Forms.Button btnGyr;
        private System.Windows.Forms.Button btnCamera1;
        private System.Windows.Forms.Button btnCamera0;
        private System.Windows.Forms.Button btnWifi;
        private System.Windows.Forms.Button btnGps;
        private System.Windows.Forms.Button btnBluetooth;
        private System.Windows.Forms.Button btnSD;
        private System.Windows.Forms.Button btnOtg;
        private System.Windows.Forms.Button btnSim;
        private System.Windows.Forms.Button btnRecord;
        private System.Windows.Forms.Button btnVib;
        private System.Windows.Forms.Button btnDial;
        private System.Windows.Forms.Button btnVer;
        private System.Windows.Forms.Button btnBattery;
        private System.Windows.Forms.Button btnDisk;
        private System.Windows.Forms.Button btnKey;
        private System.Windows.Forms.Button btnTouch;
        private System.Windows.Forms.Button btnTip;
        private System.Windows.Forms.Button btnRedScreen;
        private System.Windows.Forms.Button btnGreenScreen;
        private System.Windows.Forms.Button btnBlue;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button10;
    }
}

