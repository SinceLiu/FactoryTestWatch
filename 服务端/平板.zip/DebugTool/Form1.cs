﻿using DebugTool.Libs;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;

namespace DebugTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            TCPServer.Instance.Update += AddDTU;
            TCPServer.Instance.ShowMessage += ShowMessage;
            TCPServer.Instance.Disconn += Disconn;

            textBox1.Text = @"E:\1.txt";
        }

        private void btnInit_Click(object sender, EventArgs e)
        {
            TCPServer.Instance.Init();
        }

        private void AddDTU(string ip)
        {
            new Thread(() =>
            {
                Action action = () =>
                {
                    cbDTU.Items.Add(ip);
                    cbDTU.SelectedText = ip;
                    ShowMessage(ip + "已连接上服务器.");
                };
                Invoke(action);
            }).Start();
        }

        public void ShowMessage(string msg)
        {
            new Thread(() =>
            {
                Action action = () =>
                {
                    tbLog.AppendText(DateTime.Now.ToString("HH:mm:ss") + " " + msg + "\r\n");
                    this.tbLog.Focus();//获取焦点
                    this.tbLog.Select(this.tbLog.TextLength, 0);//光标定位到文本最后
                    this.tbLog.ScrollToCaret();//滚动到光标处
                };
                Invoke(action);
            }).Start();
        }

        public void Disconn(string ip)
        {
            new Thread(() =>
            {
                Action action = () =>
                {
                    Phone inst = TCPServer.Instance.Phones.Find(o => o.ip == ip);
                    TCPServer.Instance.Phones.Remove(inst);
                    cbDTU.Items.Remove(ip);
                    if (cbDTU.Items.Count == 0)
                    {
                        cbDTU.Text = "";
                    }
                    else
                        cbDTU.SelectedIndex = 0;
                };
                Invoke(action);
            }).Start();
        }

        private void btnSN_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.sn = "get";
            //inst.showMessage = "-WIFI测试结果：【PASS】-版本号测试结果：【PASS】-容量检查测试结果：【PASS】-SN条码测试结果：【PASS】-黑屏测试结果：【FAIL】-电池测试结果：【PASS】-白屏测试结果：【FAIL】-后摄白场测试结果：【FAIL】-后摄白场测试结果：【FAIL】-前摄白场测试结果：【FAIL】-前摄白场测试结果：【FAIL】-前摄黑场测试结果：【FAIL】-前摄黑场测试结果：【FAIL】-环境光测试结果：【FAIL】-SD卡测试结果：【FAIL】-前摄近焦测试结果：【FAIL】-前摄近焦测试结果：【FAIL】-后摄近焦测试结果：【FAIL】-后摄近焦测试结果：【FAIL】-重力感应测试结果：【FAIL】-后摄黑场测试结果：【FAIL】-后摄黑场测试结果：【FAIL】-音量键测试结果：【PASS】-后摄远焦测试结果：【FAIL】-后摄远焦测试结果：【FAIL】-触摸屏测试结果：【FAIL】-OTG测试结果：【FAIL】";
            TCPServer.Instance.Send(inst);
            //inst.sn = null;
            inst.showMessage = null;

            //Phone p = new Phone();
            //p.ip = "192.168.1.254";
            //p.sn = "get";
            //p.wifi = "get";
            //p.bluetooth = "get";
            //p.flag = "get";
            //p.screen = "black";
            //p.socket = null;
            //ShowMessage(JsonConvert.SerializeObject(p));
            //TCPServer.Instance.Send(p);
        }

        private void btnFlag_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.flag = "get";
            TCPServer.Instance.Send(inst);
            inst.flag = null;
        }

        private void btnLight_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.light = "get";
            inst.proximity = "get";
            TCPServer.Instance.Send(inst);
            inst.light = null;
        }

        private void btnAcc_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.accelerometer = "get";
            TCPServer.Instance.Send(inst);
            inst.accelerometer = null;
        }

        private void btnPro_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.proximity = "get";
            TCPServer.Instance.Send(inst);
            inst.proximity = null;
        }

        private void btnMag_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.magnetometer = "get";
            TCPServer.Instance.Send(inst);
            inst.magnetometer = null;
        }

        private void btnGyr_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.gyroscope = "get";
            TCPServer.Instance.Send(inst);
            inst.gyroscope = null;
        }

        private void btnCamera1_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.camera = "CAM_FW-1";
            TCPServer.Instance.Send(inst);
            inst.camera = null;

        }

        private void btnCamera0_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.camera = "CAM_BW-0";
            //CameraParam param = new CameraParam();
            //param.flashMode = "0";
            //param.resolutionRatio = "2592:1944";
            //param.isFocus = false;
            //param.compressionRatio = "1";
            //inst.param = param;
            TCPServer.Instance.Send(inst);
            inst.camera = null;
        }

        private void btnWifi_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.wifi = "get";
            TCPServer.Instance.Send(inst);
            inst.wifi = null;
        }

        private void btnGps_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.gps = "get";
            TCPServer.Instance.Send(inst);
            inst.gps = null;
        }

        private void btnBluetooth_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.bluetooth = "get";
            TCPServer.Instance.Send(inst);
            inst.bluetooth = null;
        }

        private void btnSD_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.sd = "get";
            TCPServer.Instance.Send(inst);
            inst.sd = null;
        }

        private void btnOtg_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.otg = "get";
            TCPServer.Instance.Send(inst);
            inst.otg = null;
        }

        private void btnSim_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.sim = "get";
            TCPServer.Instance.Send(inst);
            inst.sim = null;
        }

        private void btnRecord_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.record = "get";
            inst.timeout = 30;
            TCPServer.Instance.Send(inst);
            inst.record = null;
        }

        private void btnVib_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.vibrator = "get";
            TCPServer.Instance.Send(inst);
            inst.vibrator = null;
        }

        private void btnDial_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.dial = "get";
            TCPServer.Instance.Send(inst);
            inst.dial = null;
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.version = "get";
            TCPServer.Instance.Send(inst);
            inst.version = null;
        }

        private void btnBattery_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.battery = "get";
            TCPServer.Instance.Send(inst);
            inst.battery = null;
        }

        private void btnDisk_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.disk = "get";
            TCPServer.Instance.Send(inst);
            inst.disk = null;
        }

        private void btnKey_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.key = "get";
            inst.timeout = 5;
            TCPServer.Instance.Send(inst);
            inst.key = null;
            inst.timeout = 0;
        }

        private void btnTouch_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.touch = "start";
            inst.screen = null;
            TCPServer.Instance.Send(inst);
        }

        private void btnTip_Click(object sender, EventArgs e)
        {
            //Phone inst = TCPServer.Instance.Phones[0];
            //inst.tip = "red";
            //TCPServer.Instance.Send(inst);
            //inst.tip = null;
        }

        private void btnRedScreen_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.screen = "black";
            inst.ScreenOperation = 0;
            inst.timeout = 6;
            TCPServer.Instance.Send(inst);
            inst.screen = null;
        }

        private void btnGreenScreen_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.screen = "white";
            inst.ScreenOperation = 0;
            TCPServer.Instance.Send(inst);
            inst.screen = null;
        }

        private void btnBlue_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.wifi = "close";
            TCPServer.Instance.Send(inst);
            inst.screen = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(StartReceive);
            t.Start();
        }

        private void StartReceive()
        {
            Phone inst = TCPServer.Instance.Phones[0];
            byte[] dataBuffer = new byte[1024 * 4];
            ShowMessage("开始接收");
            int count = inst.socket.Receive(dataBuffer);
            ShowMessage("接收完毕");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.screen = "white";
            inst.ScreenOperation = 1;
            TCPServer.Instance.Send(inst);
            inst.screen = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.screen = "black";
            inst.ScreenOperation = 1;
            inst.timeout = 6;
            TCPServer.Instance.Send(inst);
            inst.screen = null;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.touch = "end";
            TCPServer.Instance.Send(inst);
        }



        private void LoopSwitchScreen()
        {
            Stop = false;

            while (true)
            {
                i = 0;

                foreach (var p in TCPServer.Instance.Phones)
                {
                    Thread t = new Thread(new ParameterizedThreadStart(OnePhoneSwitch));
                    t.Start(p);
                }

                if (Stop)
                {
                    ShowMessage("停了");
                    foreach (var p in TCPServer.Instance.Phones)
                    {
                        p.screen = null;
                        ShowMessage(p.sn + "墨迹次数" + p.GetSlowtime());
                    }
                    Stop = false;
                    return;
                }
                are.WaitOne();
            }
        }



        private void LoopTakePicture_0()
        {
            Stop = false;

            int j = 0;

            List<Phone> switchscreen = new List<Phone>();

            List<Phone> takepicture = new List<Phone>();

            foreach (var tp in TCPServer.Instance.Phones)
            {
                if (j % 2 == 0)
                {
                    switchscreen.Add(tp);
                }
                else
                {
                    takepicture.Add(tp);
                }
                j++;
            }

            while (true)
            {
                i = 0;
                //List<Phone> switchscreen = new List<Phone>() { TCPServer.Instance.Phones[0], TCPServer.Instance.Phones[1] };

                //List<Phone> takepicture = new List<Phone>() { TCPServer.Instance.Phones[2], TCPServer.Instance.Phones[3], TCPServer.Instance.Phones[4], TCPServer.Instance.Phones[5] };

                foreach (var p in TCPServer.Instance.Phones)
                {
                    if (switchscreen.Contains(p))
                    {
                        Thread t1 = new Thread(new ParameterizedThreadStart(OnePhoneSwitch));
                        t1.Start(p);
                    }
                    if (takepicture.Contains(p))
                    {
                        Thread t = new Thread(new ParameterizedThreadStart(OnePhoneTakePicture));
                        t.Start(p);
                    }
                    //Thread t = new Thread(new ParameterizedThreadStart(OnePhoneTakePicture));
                    //t.Start(p);
                }

                if (Stop)
                {
                    ShowMessage("停了");
                    foreach (var p in TCPServer.Instance.Phones)
                    {
                        p.camera = null;
                        ShowMessage(p.sn + "墨迹次数" + p.GetSlowtime());
                    }
                    Stop = false;
                    return;
                }
                are.WaitOne();
            }
        }

        int i = 0;
        AutoResetEvent are = new AutoResetEvent(false);

        private void OnePhoneSwitch(object pp)
        {
            Phone p = pp as Phone;
            p.screen = "white";
            p.sn = "get";
            p.ScreenOperation = 0;
            DateTime st = DateTime.Now;
            TCPServer.Instance.SendWithoutReceive(p);
            string rec = TCPServer.Instance.AsSynReceive(p);
            DateTime et = DateTime.Now;

            if ((et - st).TotalSeconds > 2)
            {
                p.AddSlowTime();
            }

            st = DateTime.Now;
            p.ScreenOperation = 1;
            TCPServer.Instance.SendWithoutReceive(p);
            rec = TCPServer.Instance.AsSynReceive(p);
            et = DateTime.Now;

            if ((et - st).TotalSeconds > 2)
            {
                p.AddSlowTime();
            }


            p.screen = "black";
            p.sn = "get";
            p.ScreenOperation = 0;
            st = DateTime.Now;
            TCPServer.Instance.SendWithoutReceive(p);
            rec = TCPServer.Instance.AsSynReceive(p);
            et = DateTime.Now;

            if ((et - st).TotalSeconds > 2)
            {
                p.AddSlowTime();
            }

            st = DateTime.Now;
            p.ScreenOperation = 1;
            TCPServer.Instance.SendWithoutReceive(p);
            rec = TCPServer.Instance.AsSynReceive(p);
            et = DateTime.Now;

            if ((et - st).TotalSeconds > 2)
            {
                p.AddSlowTime();
            }
            i++;
            if (i == TCPServer.Instance.Phones.Count)
            {
                are.Set();
            }
        }

        private void OnePhoneTakePicture(object pp)
        {
            Phone p = pp as Phone;
            DateTime st = DateTime.Now;
            p.camera = "CAM_FW-1";
            p.sn = "get";
            TCPServer.Instance.SendWithoutReceive(p);
            string rec = TCPServer.Instance.AsSynReceive(p);
            DateTime et = DateTime.Now;
                       
            Thread.Sleep(1000);
            i++;
            if (i == TCPServer.Instance.Phones.Count)
            {
                are.Set();
            }
        }

        private void LoopTakePicture_1()
        {
            while (true)
            {
                i = 0;
                foreach (var p in TCPServer.Instance.Phones)
                {
                    Thread t = new Thread(new ParameterizedThreadStart(OnePhoneTakePicture));
                    t.Start(p);
                }

                if (Stop)
                {
                    ShowMessage("停了");
                    Stop = false;
                    return;
                }
                are.WaitOne();
            }
        }

        private void TakePicFront(object pp)
        {
            Phone p = pp as Phone;
            DateTime st = DateTime.Now;
            p.camera = "CAM_FW-1";
            p.sn = "get";
            TCPServer.Instance.SendWithoutReceive(p);
            string rec = TCPServer.Instance.AsSynReceive(p);
            DateTime et = DateTime.Now;

            Thread.Sleep(2000);

            //if ((et - st).TotalSeconds > 3.5)
            //{
            //    p.AddSlowTime();
            //}
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(LoopSwitchScreen);
            t.Start();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(LoopTakePicture_0);
            t.Start();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(LoopTakePicture_1);
            t.Start();
        }

        bool Stop = false;

        private void button8_Click(object sender, EventArgs e)
        {
            Stop = true;
            are.Set();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.AuxiliaryCamera = "get";
            TCPServer.Instance.Send(inst);
            inst.AuxiliaryCamera = null;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string tempbar;
            int WIFIPassCount = 0;
            int WIFIFailCount = 0;
            int VersionPassCount = 0;
            int VersionFailCount = 0;
            int VolumePassCount = 0;
            int VolumeFailCount = 0;
            int BlankscreenPassCount = 0;
            int BlankscreenFailCount = 0;
            int WhitescreenPassCount = 0;
            int WhitescreenFailCount = 0;
            int BackshotWhiteFieldPassCount = 0;
            int BackshotWhiteFieldFailCount = 0;
            int LoudspeakerPassCount = 0;
            int LoudspeakerFailCount = 0;
            int ProspectiveWhiteFieldPassCount = 0;
            int ProspectiveWhiteFieldFailCount = 0;
            int ApproachingLightPassCount = 0;
            int ApproachingLightFailCount = 0;
            int SurroundLightPassCount = 0;
            int SurroundLightFailCount = 0;
            int BluetoothPassCount = 0;
            int BluetoothFailCount = 0;
            int ProactiveNearFocusPassCount = 0;
            int ProactiveNearFocusFailCount = 0;
            int PosteriorCloseFocusPassCount = 0;
            int PosteriorCloseFocusFailCount = 0;
            int BackshotBlackFieldPassCount = 0;
            int BackshotBlackFieldFailCount = 0;
            int PosteriorTelefocusPassCount = 0;
            int PosteriorTelefocusFailCount = 0;
            int TouchPassCount = 0;
            int TouchFailCount = 0;
            int EarphonePassCount = 0;
            int EarphoneFailCount = 0;
            int keyPassCount = 0;
            int keyFailCount = 0;

            int PassCount = 0;
            int FailCount = 0;

            FileStream fs = new FileStream(textBox1.Text, FileMode.OpenOrCreate, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            while (true)
            {
                tempbar = sr.ReadLine();
                if (tempbar == null)
                {
                    break;
                }
                if (tempbar.Contains("WIFI测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    WIFIPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    WIFIFailCount += num2;
                }

                if (tempbar.Contains("版本测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    VersionPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    VersionFailCount += num2;
                }

                if (tempbar.Contains("容量检查测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    VolumePassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    VolumeFailCount += num2;
                }

                if (tempbar.Contains("黑屏测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    BlankscreenPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    BlankscreenFailCount += num2;
                }

                if (tempbar.Contains("白屏测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    WhitescreenPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    WhitescreenFailCount += num2;
                }

                if (tempbar.Contains("后摄白场测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    BackshotWhiteFieldPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    BackshotWhiteFieldFailCount += num2;
                }

                if (tempbar.Contains("扬声器播音/平板麦录音测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    LoudspeakerPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    LoudspeakerFailCount += num2;
                }

                if (tempbar.Contains("前摄白场测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    ProspectiveWhiteFieldPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    ProspectiveWhiteFieldFailCount += num2;
                }

                if (tempbar.Contains("接近光测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    ApproachingLightPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    ApproachingLightFailCount += num2;
                }

                if (tempbar.Contains("环境光测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    SurroundLightPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    SurroundLightFailCount += num2;
                }

                if (tempbar.Contains("蓝牙测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    BluetoothPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    BluetoothFailCount += num2;
                }

                if (tempbar.Contains("前摄近焦测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    ProactiveNearFocusPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    ProactiveNearFocusFailCount += num2;
                }

                if (tempbar.Contains("后摄近焦测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    PosteriorCloseFocusPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    PosteriorCloseFocusFailCount += num2;
                }

                if (tempbar.Contains("后摄黑场测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    BackshotBlackFieldPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    BackshotBlackFieldFailCount += num2;
                }

                if (tempbar.Contains("后摄远焦测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    PosteriorTelefocusPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    PosteriorTelefocusFailCount += num2;
                }

                if (tempbar.Contains("触摸测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    TouchPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    TouchFailCount += num2;
                }

                if (tempbar.Contains("耳机(L/R)播音/耳机麦录音测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    EarphonePassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    EarphoneFailCount += num2;
                }

                if (tempbar.Contains("按键测试"))
                {
                    string r1 = tempbar.ToUpper().Replace("PASS", "");
                    int num1 = (tempbar.ToUpper().Length - r1.Length) / 4;
                    keyPassCount += num1;

                    string r2 = tempbar.ToUpper().Replace("FAIL", "");
                    int num2 = (tempbar.ToUpper().Length - r2.Length) / 4;
                    keyFailCount += num2;
                }

                string rp = tempbar.ToUpper().Replace("PASS", "");
                int nump = (tempbar.ToUpper().Length - rp.Length) / 4;
                PassCount += nump;

                string rf = tempbar.ToUpper().Replace("FAIL", "");
                int numf = (tempbar.ToUpper().Length - rf.Length) / 4;
                FailCount += numf;

            }
            sr.Close();
            fs.Close();
            ShowMessage(textBox1.Text + "中WIFI测试Pass有" + WIFIPassCount + "个，Fail有" + WIFIFailCount + "个");
            ShowMessage(textBox1.Text + "中版本测试Pass有" + VersionPassCount + "个，Fail有" + VersionFailCount + "个");
            ShowMessage(textBox1.Text + "中容量检查测试Pass有" + VolumePassCount + "个，Fail有" + VolumeFailCount + "个");
            ShowMessage(textBox1.Text + "中黑屏测试Pass有" + BlankscreenPassCount + "个，Fail有" + BlankscreenFailCount + "个");
            ShowMessage(textBox1.Text + "中白屏测试Pass有" + WhitescreenPassCount + "个，Fail有" + WhitescreenFailCount + "个");
            ShowMessage(textBox1.Text + "中后摄白场测试Pass有" + BackshotWhiteFieldPassCount + "个，Fail有" + BackshotWhiteFieldFailCount + "个");
            ShowMessage(textBox1.Text + "中扬声器播音/平板麦录音测试Pass有" + LoudspeakerPassCount + "个，Fail有" + LoudspeakerFailCount + "个");
            ShowMessage(textBox1.Text + "中前摄白场测试Pass有" + ProspectiveWhiteFieldPassCount + "个，Fail有" + ProspectiveWhiteFieldFailCount + "个");
            ShowMessage(textBox1.Text + "中接近光测试Pass有" + ApproachingLightPassCount + "个，Fail有" + ApproachingLightFailCount + "个");
            ShowMessage(textBox1.Text + "中环境光测试Pass有" + SurroundLightPassCount + "个，Fail有" + SurroundLightFailCount + "个");
            ShowMessage(textBox1.Text + "中蓝牙测试Pass有" + BluetoothPassCount + "个，Fail有" + BluetoothFailCount + "个");

            ShowMessage(textBox1.Text + "中前摄近焦测试Pass有" + ProactiveNearFocusPassCount + "个，Fail有" + ProactiveNearFocusFailCount + "个");
            ShowMessage(textBox1.Text + "中后摄近焦测试Pass有" + PosteriorCloseFocusPassCount + "个，Fail有" + PosteriorCloseFocusFailCount + "个");
            ShowMessage(textBox1.Text + "中后摄黑场测试Pass有" + BackshotBlackFieldPassCount + "个，Fail有" + BackshotBlackFieldFailCount + "个");
            ShowMessage(textBox1.Text + "中后摄远焦测试Pass有" + PosteriorTelefocusPassCount + "个，Fail有" + PosteriorTelefocusFailCount + "个");

            ShowMessage(textBox1.Text + "中触摸测试Pass有" + TouchPassCount + "个，Fail有" + TouchFailCount + "个");
            ShowMessage(textBox1.Text + "中耳机(L/R)播音/耳机麦录音测试Pass有" + EarphonePassCount + "个，Fail有" + EarphoneFailCount + "个");
            ShowMessage(textBox1.Text + "中按键测试Pass有" + keyPassCount + "个，Fail有" + keyFailCount + "个");

            ShowMessage(textBox1.Text + "中Pass一共有" + PassCount + "个，Fail一共有" + FailCount + "个");

        }

        private void button11_Click(object sender, EventArgs e)
        {
            MessageBox.Show( "服务器开启错误");//czh
            Phone inst = TCPServer.Instance.Phones[0];
            inst.cpu = "get";
            //TCPServer.Instance.Send(inst);
            // inst.cpu = null;

            //string rec = TCPServer.Instance.AsSynReceive(inst);//czh
            ShowMessage("CPU-xxxx");//czh

        }

        private void button12_Click(object sender, EventArgs e)
        {
            Phone p = TCPServer.Instance.Phones[0];
            p.screen = "red";
            p.ScreenOperation = 0;
            DateTime st = DateTime.Now;
            TCPServer.Instance.SendWithoutReceive(p);
            string rec = TCPServer.Instance.AsSynReceive(p);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Phone p = TCPServer.Instance.Phones[0];
            p.screen = "red";
            p.ScreenOperation = 1;
            DateTime st = DateTime.Now;
            TCPServer.Instance.SendWithoutReceive(p);
            string rec = TCPServer.Instance.AsSynReceive(p);
        }

        private void button13_Click(object sender, EventArgs e)
        {

            Phone p = TCPServer.Instance.Phones[0];
            p.screen = "green";
            p.ScreenOperation = 0;
            DateTime st = DateTime.Now;
            TCPServer.Instance.SendWithoutReceive(p);
            string rec = TCPServer.Instance.AsSynReceive(p);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Phone p = TCPServer.Instance.Phones[0];
            p.screen = "green";
            p.ScreenOperation = 1;
            DateTime st = DateTime.Now;
            TCPServer.Instance.SendWithoutReceive(p);
            string rec = TCPServer.Instance.AsSynReceive(p);

        }

        private void button14_Click(object sender, EventArgs e)
        {
            Phone p = TCPServer.Instance.Phones[0];
            p.screen = "blue";
            p.ScreenOperation = 0;
            DateTime st = DateTime.Now;
            TCPServer.Instance.SendWithoutReceive(p);
            string rec = TCPServer.Instance.AsSynReceive(p);

            //aaaa
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Phone p = TCPServer.Instance.Phones[0];
            p.screen = "blue";
            p.ScreenOperation = 1;
            DateTime st = DateTime.Now;
            TCPServer.Instance.SendWithoutReceive(p);
            string rec = TCPServer.Instance.AsSynReceive(p);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.adc = "get";
            TCPServer.Instance.Send(inst);
            inst.adc = null;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.charge = "get";
            TCPServer.Instance.Send(inst);
            inst.charge = null;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.board = "get";
            TCPServer.Instance.Send(inst);
            inst.board = null;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Phone inst = TCPServer.Instance.Phones[0];
            inst.IMEI = "get";
            TCPServer.Instance.Send(inst);
            inst.IMEI = null;
        }

        private void tbLog_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
